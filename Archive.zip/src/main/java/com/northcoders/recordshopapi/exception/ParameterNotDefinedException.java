package com.northcoders.recordshopapi.exception;

public class ParameterNotDefinedException extends RuntimeException {

    public ParameterNotDefinedException(String message) {
        super(message);
    }
}
