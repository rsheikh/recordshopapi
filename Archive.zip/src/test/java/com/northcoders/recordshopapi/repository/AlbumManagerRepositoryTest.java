package com.northcoders.recordshopapi.repository;

import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.*;

class AlbumManagerRepositoryTest {

    @BeforeEach
    void setUp() {
    }
}