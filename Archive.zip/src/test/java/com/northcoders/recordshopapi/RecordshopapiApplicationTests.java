package com.northcoders.recordshopapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecordshopapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
